/**
 * undoRedoTracker.ts
 *
 * Mirrors VS Code's undo/redo stack but with attribution tags.
 *
 * The core problem VS Code creates for us:
 *   - Ctrl+Z fires onDidChangeTextDocument with reason=1
 *   - The text is already restored by the time our handler runs
 *   - We have NO idea what the previous state was unless we stored it
 *   - We cannot intercept BEFORE VS Code applies the undo
 *
 * Our stack must stay PERFECTLY in sync with VS Code's stack.
 * Any desync = wrong attribution restored on undo/redo.
 *
 * ── Sync strategy ─────────────────────────────────────────────────────────────
 *
 * VS Code groups edits by a ~1s idle timer into single undo entries.
 * We mirror this by pushing one snapshot per "edit group" not per keystroke.
 * We detect group boundaries using the document version number.
 *
 * ── Why updates sometimes don't apply ─────────────────────────────────────────
 *
 * Common causes of the "not updating" bug:
 *   1. Snapshot pushed AFTER applyChange instead of BEFORE
 *   2. Undo stack cleared incorrectly on non-edit events
 *   3. Buffer length drift causing integrity failures that silently reinitialize
 *   4. Multi-cursor changes processed in wrong order (top-to-bottom instead of bottom-to-top)
 *   5. event.reason check done AFTER other logic that already mutated state
 */

import * as vscode from 'vscode';
import * as path   from 'path';
import * as fs     from 'fs';

// ─────────────────────────────────────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────────────────────────────────────

export type AuthorTag = 'H' | 'L' | 'C';

export interface AttributionRun {
  tag:    AuthorTag;
  length: number;
  time:   number;   // Date.now() when this run was created
}

interface Snapshot {
  runs:       AttributionRun[];
  docVersion: number;   // vscode document version at snapshot time
  timestamp:  number;   // wall clock for debugging
}

// ─────────────────────────────────────────────────────────────────────────────
// RLE ATTRIBUTION BUFFER
// ─────────────────────────────────────────────────────────────────────────────

export class AttributionBuffer {
  private runs:  AttributionRun[] = [];
  private _len = 0;

  get totalLength(): number { return this._len; }

  // ── Initialize ─────────────────────────────────────────────────────────────

  init(docLength: number, tag: AuthorTag = 'H', time = Date.now()): void {
    this.runs = docLength > 0 ? [{ tag, length: docLength, time }] : [];
    this._len  = docLength;
  }

  // ── Core change ─────────────────────────────────────────────────────────────

  applyChange(
    rangeOffset:  number,
    rangeLength:  number,
    insertedText: string,
    tag:          AuthorTag,
    time:         number
  ): void {
    const ilen = insertedText.length;

    if (rangeLength > 0) this._delete(rangeOffset, rangeLength);
    if (ilen        > 0) this._insert(rangeOffset, { tag, length: ilen, time });

    this._len = this._len - rangeLength + ilen;
  }

  // ── Stats ───────────────────────────────────────────────────────────────────

  count(): Record<AuthorTag, number> {
    const r: Record<AuthorTag, number> = { H: 0, L: 0, C: 0 };
    for (const run of this.runs) r[run.tag] += run.length;
    return r;
  }

  getRunsWithOffsets(): Array<{ tag: AuthorTag; start: number; end: number }> {
    const out: Array<{ tag: AuthorTag; start: number; end: number }> = [];
    let pos = 0;
    for (const run of this.runs) {
      out.push({ tag: run.tag, start: pos, end: pos + run.length });
      pos += run.length;
    }
    return out;
  }

  // ── Retroactive reclassify (called when cline-hooks.json updates) ────────────

  reclassify(
    windows:  Array<{ file: string; startTime: number; endTime: number; tool: string }>,
    filePath: string
  ): boolean {
    const fileName = path.basename(filePath);
    let changed = false;

    for (const run of this.runs) {
      if (run.tag !== 'H') continue;       // only H → L, never L → H
      if (run.length <= 2)  continue;       // 1-2 chars = human keystrokes

      for (const w of windows) {
        if (path.basename(w.file) !== fileName) continue;
        if (run.time >= w.startTime && run.time <= w.endTime) {
          run.tag = 'L';
          changed  = true;
          break;
        }
      }
    }

    if (changed) this.runs = this._merge(this.runs);
    return changed;
  }

  // ── Serialization ────────────────────────────────────────────────────────────

  serialize(): AttributionRun[] {
    return this.runs.map(r => ({ ...r }));
  }

  restore(runs: AttributionRun[]): void {
    this.runs = runs.map(r => ({ ...r }));
    this._len  = runs.reduce((s, r) => s + r.length, 0);
  }

  static from(runs: AttributionRun[]): AttributionBuffer {
    const b = new AttributionBuffer();
    b.restore(runs);
    return b;
  }

  // ── Internal ────────────────────────────────────────────────────────────────

  private _delete(offset: number, length: number): void {
    const end = offset + length;
    const out: AttributionRun[] = [];
    let pos = 0;

    for (const run of this.runs) {
      const rEnd = pos + run.length;

      if (rEnd <= offset || pos >= end) {
        // Entirely outside deletion zone — keep
        out.push({ ...run });
      } else {
        // Overlaps — keep parts outside deletion zone
        const before = offset - pos;
        const after  = rEnd - end;
        if (before > 0) out.push({ tag: run.tag, length: before,          time: run.time });
        if (after  > 0) out.push({ tag: run.tag, length: Math.max(0,after), time: run.time });
      }
      pos = rEnd;
    }

    this.runs = this._merge(out);
  }

  private _insert(offset: number, newRun: AttributionRun): void {
    const out: AttributionRun[] = [];
    let pos      = 0;
    let inserted = false;

    for (const run of this.runs) {
      const rEnd = pos + run.length;

      if (inserted || rEnd <= offset) {
        out.push({ ...run });
      } else if (pos >= offset) {
        if (!inserted) { out.push({ ...newRun }); inserted = true; }
        out.push({ ...run });
      } else {
        // offset falls inside this run — split
        const before = offset - pos;
        const after  = rEnd   - offset;
        if (before > 0) out.push({ tag: run.tag, length: before, time: run.time });
        out.push({ ...newRun });
        inserted = true;
        if (after  > 0) out.push({ tag: run.tag, length: after,  time: run.time });
      }
      pos = rEnd;
    }

    if (!inserted) out.push({ ...newRun });
    this.runs = this._merge(out);
  }

  private _merge(runs: AttributionRun[]): AttributionRun[] {
    const out: AttributionRun[] = [];
    for (const run of runs) {
      if (run.length <= 0) continue;
      const last = out[out.length - 1];
      // Merge only if same tag AND same time bucket (within 2s = same edit group)
      if (last && last.tag === run.tag && Math.abs(last.time - run.time) < 2000) {
        last.length += run.length;
      } else {
        out.push({ ...run });
      }
    }
    return out;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// UNDO / REDO STACK
// ─────────────────────────────────────────────────────────────────────────────

const MAX_STACK = 200;

export class UndoRedoStack {
  private past:   Snapshot[] = [];   // undo stack: oldest → newest (top = most recent)
  private future: Snapshot[] = [];   // redo stack: oldest → newest (top = next redo)

  // ── Called BEFORE every normal (non-undo/redo) change ──────────────────────

  /**
   * Push a snapshot of the current buffer onto the undo stack.
   *
   * VS Code groups rapid keystrokes into one undo entry via a ~1s idle timer.
   * We mirror this by REPLACING the top entry if the doc version is consecutive
   * (same edit group) rather than always pushing a new entry.
   *
   * This keeps our stack depth in sync with VS Code's stack depth.
   */
  pushUndo(buf: AttributionBuffer, docVersion: number): void {
    const snap: Snapshot = {
      runs:       buf.serialize(),
      docVersion,
      timestamp:  Date.now(),
    };

    const top = this.past[this.past.length - 1];

    // If last snapshot was from the same edit group (consecutive versions),
    // replace it instead of pushing — mirrors VS Code's grouping behavior
    if (top && docVersion - top.docVersion <= 1 && Date.now() - top.timestamp < 1000) {
      // Keep the oldest snapshot in the group (what state was BEFORE the group started)
      // so undoing takes you all the way back to before the group
      // → do NOT replace, the original pre-group state is what we want
    } else {
      this.past.push(snap);
      if (this.past.length > MAX_STACK) this.past.shift();
    }

    // Any new edit clears the redo stack — same as VS Code
    this.future = [];
  }

  // ── Called when event.reason === 1 (UNDO) ──────────────────────────────────

  /**
   * Restore the previous buffer state.
   * Returns the snapshot to restore, or null if stack is empty.
   *
   * IMPORTANT: Call this BEFORE touching the buffer.
   * Save current state to redo stack first.
   */
  undo(currentBuf: AttributionBuffer, docVersion: number): Snapshot | null {
    if (this.past.length === 0) return null;

    // Save current state to redo stack so Ctrl+Y works
    this.future.push({
      runs:       currentBuf.serialize(),
      docVersion,
      timestamp:  Date.now(),
    });
    if (this.future.length > MAX_STACK) this.future.shift();

    return this.past.pop()!;
  }

  // ── Called when event.reason === 2 (REDO) ──────────────────────────────────

  /**
   * Restore the next buffer state.
   * Returns the snapshot to restore, or null if stack is empty.
   */
  redo(currentBuf: AttributionBuffer, docVersion: number): Snapshot | null {
    if (this.future.length === 0) return null;

    // Save current state to undo stack
    this.past.push({
      runs:       currentBuf.serialize(),
      docVersion,
      timestamp:  Date.now(),
    });
    if (this.past.length > MAX_STACK) this.past.shift();

    return this.future.pop()!;
  }

  // ── Diagnostics ─────────────────────────────────────────────────────────────

  undoDepth():  number { return this.past.length; }
  redoDepth():  number { return this.future.length; }

  clear(): void {
    this.past   = [];
    this.future = [];
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PER-FILE STATE
// ─────────────────────────────────────────────────────────────────────────────

interface FileState {
  buffer:    AttributionBuffer;
  undoRedo:  UndoRedoStack;
  lastDocVersion: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// ATTRIBUTION TRACKER — main class wired into VS Code events
// ─────────────────────────────────────────────────────────────────────────────

export class AttributionTracker {
  private files = new Map<string, FileState>();
  private storagePath: string;
  private saveTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(private workspaceRoot: string) {
    const dir = path.join(workspaceRoot, '.vscode');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    this.storagePath = path.join(dir, 'cline-attribution.json');
    this._load();
  }

  // ── VS Code event handler (call this from onDidChangeTextDocument) ──────────

  /**
   * THE MAIN ENTRY POINT.
   *
   * Call this at the top of your onDidChangeTextDocument handler.
   * Pass the full event object and Date.now() captured BEFORE anything else.
   *
   * Example in extension.ts:
   *   workspace.onDidChangeTextDocument(event => {
   *     const changeTime = Date.now();   // ← MUST be first line
   *     tracker.handleChangeEvent(event, changeTime, classifyFn);
   *   });
   */
  handleChangeEvent(
    event:       vscode.TextDocumentChangeEvent,
    changeTime:  number,
    classifyFn:  (
      change:   vscode.TextDocumentContentChangeEvent,
      document: vscode.TextDocument,
      time:     number
    ) => AuthorTag
  ): void {
    if (event.document.uri.scheme !== 'file') return;
    if (event.contentChanges.length === 0)    return;

    const uri     = event.document.uri.toString();
    const doc     = event.document;
    const version = doc.version;
    const docLen  = doc.getText().length;

    // ── Get or create file state ──────────────────────────────────────────────
    const state = this._getOrCreate(uri, docLen, changeTime);

    // ── CRITICAL: Check event.reason FIRST before anything else ──────────────
    const reason = (event as any).reason as number | undefined;

    if (reason === 1) {
      // ── UNDO ───────────────────────────────────────────────────────────────
      this._applyUndo(state, uri, version, docLen);
      return;   // ← MUST return immediately, do NOT process contentChanges
    }

    if (reason === 2) {
      // ── REDO ───────────────────────────────────────────────────────────────
      this._applyRedo(state, uri, version, docLen);
      return;   // ← MUST return immediately
    }

    // ── NORMAL EDIT ──────────────────────────────────────────────────────────

    // Snapshot BEFORE applying — this is what undo restores to
    state.undoRedo.pushUndo(state.buffer, version);

    // CRITICAL: Sort changes bottom-to-top (descending offset)
    // so that applying each change doesn't shift offsets of others
    const changes = [...event.contentChanges]
      .sort((a, b) => b.rangeOffset - a.rangeOffset);

    for (const change of changes) {
      const tag = classifyFn(change, doc, changeTime);
      state.buffer.applyChange(
        change.rangeOffset,
        change.rangeLength,
        change.text,
        tag,
        changeTime
      );
    }

    state.lastDocVersion = version;
    this._scheduleSave();
    this._checkIntegrity(state, uri, docLen, changeTime);
  }

  // ── Retroactive reclassification (call from logReader.onNewWindows) ─────────

  reclassifyFile(
    fileAbsPath: string,
    windows: Array<{ file: string; startTime: number; endTime: number; tool: string }>
  ): boolean {
    const uri   = vscode.Uri.file(fileAbsPath).toString();
    const state = this.files.get(uri);
    if (!state) return false;

    const changed = state.buffer.reclassify(windows, fileAbsPath);
    if (changed) this._scheduleSave();
    return changed;
  }

  reclassifyAll(
    windows: Array<{ file: string; startTime: number; endTime: number; tool: string }>
  ): string[] {
    const changed: string[] = [];
    for (const [uri, state] of this.files) {
      const fsPath = vscode.Uri.parse(uri).fsPath;
      if (state.buffer.reclassify(windows, fsPath)) {
        changed.push(uri);
      }
    }
    if (changed.length > 0) this._scheduleSave();
    return changed;
  }

  // ── File open ────────────────────────────────────────────────────────────────

  handleFileOpen(document: vscode.TextDocument): void {
    if (document.uri.scheme !== 'file') return;
    const uri    = document.uri.toString();
    const docLen = document.getText().length;
    const state  = this._getOrCreate(uri, docLen, Date.now());
    this._checkIntegrity(state, uri, docLen, Date.now());
  }

  // ── Getters for report / decoration ──────────────────────────────────────────

  getBuffer(fileUri: string): AttributionBuffer | undefined {
    return this.files.get(fileUri)?.buffer;
  }

  getAllFiles(): Map<string, AttributionBuffer> {
    const out = new Map<string, AttributionBuffer>();
    for (const [uri, state] of this.files) out.set(uri, state.buffer);
    return out;
  }

  // ── Persistence ──────────────────────────────────────────────────────────────

  flush(): void {
    if (this.saveTimer) { clearTimeout(this.saveTimer); this.saveTimer = null; }
    this._save();
  }

  // ── Internal ─────────────────────────────────────────────────────────────────

  private _getOrCreate(uri: string, docLen: number, time: number): FileState {
    if (!this.files.has(uri)) {
      const buffer = new AttributionBuffer();
      buffer.init(docLen, 'H', time);
      this.files.set(uri, {
        buffer,
        undoRedo:       new UndoRedoStack(),
        lastDocVersion: 0,
      });
    }
    return this.files.get(uri)!;
  }

  private _applyUndo(state: FileState, uri: string, version: number, docLen: number): void {
    const snap = state.undoRedo.undo(state.buffer, version);

    if (!snap) {
      // Stack empty — VS Code undid past our tracking history.
      // Reinitialize buffer to all-human (safest fallback).
      console.warn(`[Attribution] Undo stack empty for ${uri} — reinitializing`);
      state.buffer.init(docLen, 'H', Date.now());
      return;
    }

    // Restore the snapshotted runs into the buffer
    state.buffer.restore(snap.runs);
    state.lastDocVersion = version;

    // Sanity check after restore
    if (state.buffer.totalLength !== docLen) {
      console.warn(
        `[Attribution] Undo length mismatch: buf=${state.buffer.totalLength} doc=${docLen} — reinitializing`
      );
      state.buffer.init(docLen, 'H', Date.now());
      state.undoRedo.clear();
    }

    this._scheduleSave();
  }

  private _applyRedo(state: FileState, uri: string, version: number, docLen: number): void {
    const snap = state.undoRedo.redo(state.buffer, version);

    if (!snap) {
      console.warn(`[Attribution] Redo stack empty for ${uri}`);
      return;
    }

    state.buffer.restore(snap.runs);
    state.lastDocVersion = version;

    if (state.buffer.totalLength !== docLen) {
      console.warn(
        `[Attribution] Redo length mismatch: buf=${state.buffer.totalLength} doc=${docLen} — reinitializing`
      );
      state.buffer.init(docLen, 'H', Date.now());
      state.undoRedo.clear();
    }

    this._scheduleSave();
  }

  private _checkIntegrity(state: FileState, uri: string, docLen: number, time: number): void {
    if (state.buffer.totalLength === docLen) return;

    console.warn(
      `[Attribution] Buffer drift on ${path.basename(vscode.Uri.parse(uri).fsPath)}` +
      ` — buf=${state.buffer.totalLength} doc=${docLen}. Reinitializing.`
    );
    state.buffer.init(docLen, 'H', time);
    state.undoRedo.clear();   // clear history too — it's now stale
  }

  private _scheduleSave(): void {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => this._save(), 2000);
  }

  private _save(): void {
    const data: Record<string, AttributionRun[]> = {};
    for (const [uri, state] of this.files) {
      data[uri] = state.buffer.serialize();
    }
    try {
      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
      console.error('[Attribution] Save failed:', e);
    }
  }

  private _load(): void {
    if (!fs.existsSync(this.storagePath)) return;
    try {
      const data = JSON.parse(fs.readFileSync(this.storagePath, 'utf8')) as
        Record<string, AttributionRun[]>;
      for (const [uri, runs] of Object.entries(data)) {
        const buffer = AttributionBuffer.from(runs);
        this.files.set(uri, {
          buffer,
          undoRedo:       new UndoRedoStack(),
          lastDocVersion: 0,
        });
      }
      console.log(`[Attribution] Loaded ${this.files.size} file(s)`);
    } catch (e) {
      console.error('[Attribution] Load failed:', e);
    }
  }
}

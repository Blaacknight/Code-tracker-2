/**
 * extension.ts
 *
 * Shows exactly how to wire AttributionTracker into VS Code events.
 * The order of operations is CRITICAL — wrong order = wrong attribution.
 */

import * as vscode from 'vscode';
import * as path   from 'path';
import { AttributionTracker, AuthorTag } from './undoRedoTracker';
import { ClineLogReader }                from './clineLogReader';
import { DecorationManager }             from './decorationManager';
import { ReportGenerator }               from './reportGenerator';
import { isComment, isInsideComment }    from './commentDetector';

let tracker:           AttributionTracker;
let logReader:         ClineLogReader;
let decorationManager: DecorationManager;

export function activate(context: vscode.ExtensionContext): void {
  const folders = vscode.workspace.workspaceFolders;
  if (!folders?.length) return;

  const workspaceRoot = folders[0].uri.fsPath;
  tracker           = new AttributionTracker(workspaceRoot);
  logReader         = new ClineLogReader(workspaceRoot);
  decorationManager = new DecorationManager();

  logReader.start();

  // ── Retroactive reclassify when cline-hooks.json updates ──────────────────
  logReader.onNewWindows(newWindows => {
    const changedUris = tracker.reclassifyAll(newWindows);

    for (const uri of changedUris) {
      const buf = tracker.getBuffer(uri);
      if (!buf) continue;
      for (const editor of vscode.window.visibleTextEditors) {
        if (editor.document.uri.toString() === uri) {
          decorationManager.refresh(editor, buf);
        }
      }
    }

    if (changedUris.length > 0) {
      vscode.window.showInformationMessage(
        `[Attribution] Reclassified ${changedUris.length} file(s) using Cline hook log`
      );
    }
  });

  // ── CORE EVENT — onDidChangeTextDocument ──────────────────────────────────
  context.subscriptions.push(
    vscode.workspace.onDidChangeTextDocument(event => {
      // Step 1: Capture timestamp FIRST — before anything else
      const changeTime = Date.now();

      // Step 2: Pass to tracker — it handles undo/redo internally
      tracker.handleChangeEvent(event, changeTime, classify);

      // Step 3: Refresh decorations
      const editor = vscode.window.activeTextEditor;
      if (editor && editor.document === event.document) {
        const buf = tracker.getBuffer(event.document.uri.toString());
        if (buf) decorationManager.refresh(editor, buf);
      }
    })
  );

  // ── File open ──────────────────────────────────────────────────────────────
  context.subscriptions.push(
    vscode.workspace.onDidOpenTextDocument(doc => {
      tracker.handleFileOpen(doc);
    })
  );

  // ── Editor switch ──────────────────────────────────────────────────────────
  context.subscriptions.push(
    vscode.window.onDidChangeActiveTextEditor(editor => {
      if (!editor || editor.document.uri.scheme !== 'file') return;
      const buf = tracker.getBuffer(editor.document.uri.toString());
      if (buf) decorationManager.refresh(editor, buf);
    })
  );

  // ── Init already-open files ────────────────────────────────────────────────
  for (const doc of vscode.workspace.textDocuments) {
    tracker.handleFileOpen(doc);
  }

  // ── Commands ───────────────────────────────────────────────────────────────
  context.subscriptions.push(
    vscode.commands.registerCommand('clineAttrib.generateReport', () => {
      const all     = tracker.getAllFiles();
      const root    = workspaceRoot;
      const windows = logReader.getAllWindows();

      const reports = [...all.entries()].map(([uri, buf]) => {
        const counts  = buf.count();
        const tracked = counts.H + counts.L;
        const fsPath  = vscode.Uri.parse(uri).fsPath;
        const relPath = path.relative(root, fsPath);
        const fname   = path.basename(fsPath);

        return {
          filePath:     relPath,
          humanChars:   counts.H,
          llmChars:     counts.L,
          commentChars: counts.C,
          totalTracked: tracked,
          humanPercent: tracked > 0 ? Math.round((counts.H / tracked) * 100) : 0,
          llmPercent:   tracked > 0 ? Math.round((counts.L / tracked) * 100) : 0,
          llmWindows:   windows.filter(
            w => path.basename(w.file) === fname || w.file === relPath
          ).length,
        };
      }).filter(r => r.totalTracked > 0 || r.commentChars > 0)
        .sort((a, b) => b.llmPercent - a.llmPercent);

      ReportGenerator.show(context.extensionUri, reports, windows);
    }),

    vscode.commands.registerCommand('clineAttrib.toggleDecoration', () => {
      decorationManager.toggle();
      const editor = vscode.window.activeTextEditor;
      if (editor?.document.uri.scheme === 'file') {
        const buf = tracker.getBuffer(editor.document.uri.toString());
        if (buf) decorationManager.refresh(editor, buf);
      }
    }),

    vscode.commands.registerCommand('clineAttrib.reloadLog', () => {
      logReader.stop();
      logReader.start();
      vscode.window.showInformationMessage('[Attribution] Hook log reloaded');
    })
  );
}

export function deactivate(): void {
  logReader?.stop();
  tracker?.flush();
  decorationManager?.dispose();
}

// ── Classify function ─────────────────────────────────────────────────────────

function classify(
  change:   vscode.TextDocumentContentChangeEvent,
  document: vscode.TextDocument,
  time:     number
): AuthorTag {
  const text   = change.text;
  const ilen   = text.length;
  const langId = document.languageId;

  if (ilen === 0) return 'H';

  if (ilen > 2 && isComment(text, langId)) return 'C';

  if (ilen <= 10) {
    const pos  = document.positionAt(change.rangeOffset);
    const line = document.lineAt(pos.line).text;
    if (isInsideComment(line, pos.character, langId)) return 'C';
  }

  const window = logReader.isLLMTime(document.uri.fsPath, time);
  if (window) return ilen <= 2 ? 'H' : 'L';

  return 'H';
}
